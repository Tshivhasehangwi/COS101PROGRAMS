/* Name: Azwihangwisi Vhuhwavho Tshivhase
Student number: 4258306
4258306p1q1

 */
public class Main {
    public static void main(String[] args) {
        String firstName = "Azwihangwisi";
        String surName = "Tshivhase";
        int myAge = 19;
        int momAge = 51;
        System.out.println("Welcome user, this program calculates the age to which you are exactly one third to your mom's age");

        System.out.print("My first name is " + firstName );
        System.out.println(" and my surname is " +surName);
        System.out.print("My current age is " + myAge);
        System.out.println(" and my mom's current age is " +momAge);

        int y = (momAge - 3 * myAge) /2 ;
        int myAge_new = myAge + y ;
        int momAge_new = momAge + y;

        System.out.println("It will take exactly the following number of years to be exactly one third my mom's age: " + y);
        System.out.print("At that time my age will be " + myAge_new + " years old");
        System.out.println(" and my mom's age will be " + momAge_new + " years old");
    }
}